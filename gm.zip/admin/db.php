<?php

$username = 'root';
$password = '123456';
$pdo = new PDO( 'mysql:host=localhost;dbname=gm', $username, $password );

?>