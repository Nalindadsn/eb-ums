<?php
include('db.php');
include('function1.php');
if(isset($_POST["operation"]))
{
	if($_POST["operation"] == "Add")
	{
		$image = '';
		if($_FILES["user_image"]["name"] != '')
		{
			$image = upload_image();
		}
		$statement = $pdo->prepare("
			INSERT INTO products (p_name, price, cat_id, description,v_link, image) 
			VALUES (:p_name, :price, :cat_id, :description,:v_link, :image)
		");
		$result = $statement->execute(
			array(
				':p_name'	=>	$_POST["p_name"],
				':price'	=>	$_POST["price"],
				':cat_id'	=>	$_POST["cat_id"],
				':description'	=>	$_POST["description"],
				':v_link'	=>	$_POST["v_link"],
				':image'		=>	$image
			)
		);

		if(!empty($result))
		{
			echo 'Data Inserted';
		}
	}
	if($_POST["operation"] == "Edit")
	{
		$image = '';
		if($_FILES["user_image"]["name"] != '')
		{
			$image = upload_image();
		}
		else
		{
			$image = $_POST["hidden_user_image"];
		}
		$statement = $pdo->prepare(
			"UPDATE products 
			SET p_name = :p_name, price = :price, cat_id = :cat_id, description = :description, v_link = :v_link, image = :image  
			WHERE id = :id
			"
		);
		$result = $statement->execute(
			array(
				':p_name'	=>	$_POST["p_name"],
				':price'	=>	$_POST["price"],
				':cat_id'	=>	$_POST["cat_id"],
				':description'	=>	$_POST["description"],
				':v_link'	=>	$_POST["v_link"],
				':image'		=>	$image,
				':id'			=>	$_POST["user_id"]
			)
		);
		if(!empty($result))
		{
			echo 'Data Updated';
		}
	}
}

?>