<?php include 'main.php';



$stmt = $pdo->prepare("SELECT * FROM products WHERE id='".$_GET['id']."'");

$stmt->execute();

$product = $stmt->fetchAll(PDO::FETCH_ASSOC);


function formatMoney($money) {
    if($money<1) {
        $money='Rs. '.$money*100;
    }
    else {
        $dollars=intval($money);
        $cents=$money-$dollars;
        $cents=$cents*100;
        if ($cents>0) {
        $cents=$cents*100;
        }else{

        $cents="0".$cents*100;
        }
        $money='Rs. '.$dollars.'.'.$cents;
    }
    return $money;
}


?>

<!DOCTYPE html>

<!--

This is a starter template page. Use this page to start your new project from

scratch. This page gets rid of all links and provides the needed markup only.

-->

<html lang="en">

<head>

  <meta charset="utf-8">

  <meta name="viewport" content="width=device-width, initial-scale=1">

  <title>Gemmind</title>



  <!-- Google Font: Source Sans Pro -->

  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">

  <!-- Font Awesome Icons -->

  <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">

  <!-- Theme style -->

  <link rel="stylesheet" href="dist/css/adminlte.min.css">

  <style type="text/css">

    

h1 {

  font-size: 28px;

  font-weight: 700;

  margin-bottom: 5px;

}



.price {

  margin-bottom: 10px;

}



  </style>

</head>

<body class="hold-transition layout-top-nav">

<div class="wrapper">



  <!-- Navbar -->

  <nav class="main-header navbar navbar-expand-md navbar-dark navbar-dark">

    <div class="container">

      <a href="index.php" class="navbar-brand">

<img src="dist/img/AdminLTELogo3.png" style="width: 80%;">

        <span class="brand-text font-weight-light"></span>

      </a>



      <button class="navbar-toggler order-1" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">

        <span class="navbar-toggler-icon"></span>

      </button>



      <div class="collapse navbar-collapse order-3" id="navbarCollapse">

        <!-- Left navbar links -->

        <ul class="navbar-nav">

          <li class="nav-item">

            <a href="https://www.gemmind.lk/" class="nav-link">website</a>

          </li>``
<?php 

if (isset($_SESSION['name'])) {
?>

          <li class="nav-item">

            <a href="index.php" class="nav-link">

              

<?php 

if($_SESSION['role']=="Admin"){

  echo "Admin Panel";

}else if($_SESSION['role']=="Member"){

  echo "User Panel";

}else{

  

  echo "User Panel";

}



?>



            </a>

          </li>

          
<?php
}

 ?>

          

          <li class="nav-item">

            <a href="all_products.php" class="nav-link ">Products</a>

          </li>

        </ul>



      </div>



      <!-- Right navbar links -->

      <ul class="order-1 order-md-3 navbar-nav navbar-no-expand ml-auto">

     


<?php 

if (isset($_SESSION['name'])) {
?>
        <li class="nav-item">

          <a class="nav-link text-danger" href="logout.php">

            <i class="fas fa-sign-out-alt"></i> Logout

          </a>

        </li>

<?php }else{
?>

        <li class="nav-item">

          <a class="nav-link text-danger" href="logout.php">

            <i class="fas fa-sign-out-alt"></i> Sign In

          </a>

        </li>

<?php

} ?>

      </ul>

    </div>

  </nav>

  <!-- /.navbar -->



  <!-- Content Wrapper. Contains page content -->

  <div class="content-wrapper">

    <!-- Content Header (Page header) -->

    <div class="content-header">

      <div class="container">

        <div class="row mb-2">

          <div class="col-sm-6">

          </div><!-- /.col -->

          <div class="col-sm-6">

            <ol class="breadcrumb float-sm-right">

              <li class="breadcrumb-item"><a href="#">Home</a></li>

              <li class="breadcrumb-item active">All Products</li>

            </ol>

          </div><!-- /.col -->

        </div><!-- /.row -->

      </div><!-- /.container-fluid -->

    </div>

    <!-- /.content-header -->



    <!-- Main content -->

    <div class="content">

      <div class="container">

        <div class="row">





  <div class="row">



 







<?php 

foreach ($product as $p_item) { 

?>







<div class="col-md-6">



<ul class="nav nav-tabs" role="tablist">

  <li class="nav-item">

    <a class="nav-link active" data-toggle="tab" href="#tabs-1" role="tab">Image</a>

  </li>

  <li class="nav-item">

    <a class="nav-link" data-toggle="tab" href="#tabs-2" role="tab">Video</a>

  </li>

</ul><!-- Tab panes -->

<div class="tab-content">

  <div class="tab-pane active" id="tabs-1" role="tabpanel">

  <div class="column">

      <div class="thumbnail-container m-2 bg-white">











        <img class="drift-demo-trigger" style="width: 100%;" src="admin/products/<?php echo $p_item['image'] ?>">









      </div>

  </div>

  </div>



  <div class="tab-pane " id="tabs-2" role="tabpanel" style="width: 100%;position: relative;" >

  <div class="column">

      <div class="thumbnail-container m-2 bg-white">

    



<div class="embed-responsive embed-responsive-16by9" style="width: 100%;position: relative;">

  <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/<?php echo $p_item['v_link'] ?>?rel=0" allowfullscreen></iframe>

</div>





        <img class="drift-demo-trigger" style="width: 100%;" src="admin/products/<?php echo $p_item['image'] ?>">



      </div>

  </div>

  </div>









</div>





</div>

<div class="col-sm-6">

  

  <div class="column">

    <div class="details"><br><br>

      <h1><?php echo $p_item['p_name'] ?></h1>

      <p class="price"> <?php 
echo formatMoney($p_item['price']);

      ?></p>

      <p class="description">

        <?php echo $p_item['description'] ?>







<br><br><br>


<?php 
if (isset($_SESSION['name'])) {
if($_SESSION['role']=="Admin"){
?>


              <a href="newUser.php?id=<?php echo $_GET['id']; ?><?php if(isset($_GET['uid'])){
  echo "&uid=".$_GET['uid'];
} ?>" class="btn btn-outline-danger btn-block"><i class="fa fa-shopping-basket" aria-hidden="true"></i> Register and Buy</a>


<?php
}
}else{
  ?>


              <a href="newUser.php?id=<?php echo $_GET['id']; ?><?php if(isset($_GET['uid'])){
  echo "&uid=".$_GET['uid'];
} ?>" class="btn btn-outline-danger btn-block"><i class="fa fa-shopping-basket" aria-hidden="true"></i> Register and Buy</a>


  <?php

}


?>



    </div>

  </div>

</div>





























<?php



 } ?>





















































  </div>

















          <!-- /.col-md-6 -->

        </div>

        <!-- /.row -->

      </div><!-- /.container-fluid -->

    </div>

    <!-- /.content -->

  </div>

  <!-- /.content-wrapper -->



  <!-- Control Sidebar -->

  <aside class="control-sidebar control-sidebar-dark">

    <!-- Control sidebar content goes here -->

    <div class="p-3">

      <h5>Title</h5>

      <p>Sidebar content</p>

    </div>

  </aside>

  <!-- /.control-sidebar -->



  <!-- Main Footer -->

  <footer class="main-footer">

    <!-- To the right -->

  </footer>

</div>

<!-- ./wrapper -->



<!-- REQUIRED SCRIPTS -->



<!-- jQuery -->

<script src="plugins/jquery/jquery.min.js"></script>

<!-- Bootstrap 4 -->

<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>

<!-- AdminLTE App -->

<script src="dist/js/adminlte.min.js"></script>

<!-- AdminLTE for demo purposes -->

<script src="dist/js/demo.js"></script>

</body>

</html>

