
<?php


function userBal($tree_data,$left,$right){

global $pdo;
$subsF=0;
$pV=100;
$total=0;
$tp1=0;
$tp2=0;
$total2=0;
$subs=0;
$vr1=$vr2=$fb1=$fb2=0;
// $startDate = new DateTime('2021-01-24');
// $endDate = new DateTime('2021-02-22');


$stmta = $pdo->prepare("SELECT * FROM accounts WHERE status='1' AND role='Admin' ORDER BY id ASC LIMIT 1");
$stmta->execute();
// fetching rows into array
$dataaa = $stmta->fetchAll();

foreach ($dataaa as $keyData) {
$startDate = new DateTime(date('Y-m-d', strtotime($keyData['created_at'].'last sunday')));
$endDate = new DateTime(date('Y-m-d', strtotime(date("Y-m-d"))));
}




$sundays = array();
?>



<?php
$numSr=0;

$nVV=0;
$pre1=0;
$pre2=0;
while ($startDate <= $endDate) {
    if ($startDate->format('w') == 0) {


$n=0;
$n2=0;
$numV=0;
$numSr++;
$pre1=0;
$pre2=0;
foreach (fetch_recursive2($tree_data,$left) as $key11) {
 // echo $key11['created_at']."<br>";
//if ($key11['id']!=$_SESSION['name']) {
  //echo $key11['id'];

$tm=$key11['created_at'];

$time = $startDate->format('Y-m-d');

$date_one = $time; 
$date_one = strtotime($date_one);
$date_one = strtotime("+60 minutes", $date_one);
$date_one =  date('Y-m-d h:i A', $date_one);

$date_ten = strtotime($time); 
$date_ten = strtotime("-12 minutes", $date_ten); 
$date_ten = date('Y-m-d h:i A', $date_ten);

$paymentDate= date('Y-m-d', strtotime($tm) );

$contractDateBegin = date('Y-m-d h:i A', strtotime($date_ten)); 
$contractDateEnd = date('Y-m-d h:i A', strtotime($date_one));



$contractDateEnd=date('Y-m-d', strtotime($startDate->format('Y-m-d'). ' + 7 days'));



if($paymentDate > $contractDateBegin && $paymentDate < $contractDateEnd)  
{  
  $n++;
} 



//}

}

$one=0;
$one1=0;
$two=0;
$tpF=0;
$tpFF=0;

foreach (fetch_recursive2($tree_data,$right) as $key11) {
 // echo $key11['created_at']."<br>";
//if ($key11['id']!=$_SESSION['name']) {
  //echo $key11['id'];

$tm=$key11['created_at'];

$time = $startDate->format('Y-m-d');

$date_one = $time; 
$date_one = strtotime($date_one);
$date_one = strtotime("+60 minutes", $date_one);
$date_one =  date('Y-m-d h:i A', $date_one);

$date_ten = strtotime($time); 
$date_ten = strtotime("-12 minutes", $date_ten); 
$date_ten = date('Y-m-d h:i A', $date_ten);

$paymentDate= date('Y-m-d', strtotime($tm) );

$contractDateBegin = date('Y-m-d h:i A', strtotime($date_ten)); 
$contractDateEnd = date('Y-m-d h:i A', strtotime($date_one));



$contractDateEnd=date('Y-m-d', strtotime($startDate->format('Y-m-d'). ' + 7 days'));



if($paymentDate > $contractDateBegin && $paymentDate < $contractDateEnd)  
{  
  $n2++;
}
//}

}


// $arrD[] = array('name' => $n );
// $sundays[] = $startDate->format('Y-m-d');

//--if ($n>0 || $n2>0) {


?>     
<?php


/////////////////////////////////////////////
?>


<?php
 // $total+=($n*$pV);
 // $total2+=($n2*$pV);

$tpPre1=$pre1;
$tpPre2=$pre2;

$balance1=$tpPre1+$n;
$balance2=$tpPre2+$n2;



 $tp1+=$n;
 $tp2+=$n2;



$vr1=$fb1;
$vr2=$fb2;

if (min($vr1+$n,$vr2+$n2)>0) {

    if (min($vr1+$n,$vr2+$n2)>0 && min($vr1+$n,$vr2+$n2)<2) {
        
        $subs=1;
    }elseif (min($vr1+$n,$vr2+$n2)>1 && min($vr1+$n,$vr2+$n2)<4) {
        $subs=2;
    }elseif (min($vr1+$n,$vr2+$n2)>3 && min($vr1+$n,$vr2+$n2)<8) {
        $subs=4;
    }elseif (min($vr1+$n,$vr2+$n2)>7 && min($vr1+$n,$vr2+$n2)<16) {
        $subs=8;
    }elseif (min($vr1+$n,$vr2+$n2)>15 && min($vr1+$n,$vr2+$n2)<32) {
        $subs=16;
    }elseif (min($vr1+$n,$vr2+$n2)>31 && min($vr1+$n,$vr2+$n2)<64) {
        $subs=32;
    }else{
        $subs=64;
    }
}else{
    $subs=0;
}




if ($subs==1) {
$nVV++;
if ($nVV==1) {
    # code...
 $subs=1;
}else{
    $subs=0;
}
}

$fb1=$balance1-$subs+$vr1;
$fb2=$balance2-$subs+$vr2;

//$minVal=min($vr1+$n,$vr2+$n2);


// $tp1=$tp1-$subs;
// $tp2=$tp2-$subs;

$subsF+=$subs;
$one=0;

?>

<?php
//--}
//////////////////////////////////////

    }
    
    $startDate->modify('+1 day');
}





return $subsF;

}



function arraySet($tree_data,$left,$right,$ArType){

global $pdo;
$subsF=0;
$pV=100;
$total=0;
$tp1=0;
$tp2=0;
$total2=0;
$subs=0;
$vr1=$vr2=$fb1=$fb2=0;
// $startDate = new DateTime('2021-01-24');
// $endDate = new DateTime('2021-02-22');


$stmta = $pdo->prepare("SELECT * FROM accounts WHERE status='1' AND role='Admin' ORDER BY id ASC LIMIT 1");
$stmta->execute();
// fetching rows into array
$dataaa = $stmta->fetchAll();

foreach ($dataaa as $keyData) {
$startDate = new DateTime(date('Y-m-d', strtotime($keyData['created_at'].'last sunday')));
$endDate = new DateTime(date('Y-m-d', strtotime(date("Y-m-d"))));
}




$sundays = array();
?>

<?php
$numSr=0;

$nVV=0;
$pre1=0;
$pre2=0;
while ($startDate <= $endDate) {
    if ($startDate->format('w') == 0) {


$n=0;
$n2=0;
$numV=0;
$numSr++;
$pre1=0;
$pre2=0;
foreach (fetch_recursive2($tree_data,$left) as $key11) {
 // echo $key11['created_at']."<br>";
//if ($key11['id']!=$_SESSION['name']) {
  //echo $key11['id'];

$tm=$key11['created_at'];

$time = $startDate->format('Y-m-d');

$date_one = $time; 
$date_one = strtotime($date_one);
$date_one = strtotime("+60 minutes", $date_one);
$date_one =  date('Y-m-d h:i A', $date_one);

$date_ten = strtotime($time); 
$date_ten = strtotime("-12 minutes", $date_ten); 
$date_ten = date('Y-m-d h:i A', $date_ten);

$paymentDate= date('Y-m-d', strtotime($tm) );

$contractDateBegin = date('Y-m-d h:i A', strtotime($date_ten)); 
$contractDateEnd = date('Y-m-d h:i A', strtotime($date_one));



$contractDateEnd=date('Y-m-d', strtotime($startDate->format('Y-m-d'). ' + 7 days'));



if($paymentDate > $contractDateBegin && $paymentDate < $contractDateEnd)  
{  
  $n++;
} 



//}

}

$one=0;
$one1=0;
$two=0;
$tpF=0;
$tpFF=0;

foreach (fetch_recursive2($tree_data,$right) as $key11) {
 // echo $key11['created_at']."<br>";
//if ($key11['id']!=$_SESSION['name']) {
  //echo $key11['id'];

$tm=$key11['created_at'];

$time = $startDate->format('Y-m-d');

$date_one = $time; 
$date_one = strtotime($date_one);
$date_one = strtotime("+60 minutes", $date_one);
$date_one =  date('Y-m-d h:i A', $date_one);

$date_ten = strtotime($time); 
$date_ten = strtotime("-12 minutes", $date_ten); 
$date_ten = date('Y-m-d h:i A', $date_ten);

$paymentDate= date('Y-m-d', strtotime($tm) );

$contractDateBegin = date('Y-m-d h:i A', strtotime($date_ten)); 
$contractDateEnd = date('Y-m-d h:i A', strtotime($date_one));



$contractDateEnd=date('Y-m-d', strtotime($startDate->format('Y-m-d'). ' + 7 days'));



if($paymentDate > $contractDateBegin && $paymentDate < $contractDateEnd)  
{  
  $n2++;
}
//}

}

$tpPre1=$pre1;
$tpPre2=$pre2;

$balance1=$tpPre1+$n;
$balance2=$tpPre2+$n2;

 $tp1+=$n;
 $tp2+=$n2;


$vr1=$fb1;
$vr2=$fb2;

if (min($vr1+$n,$vr2+$n2)>0) {

    if (min($vr1+$n,$vr2+$n2)>0 && min($vr1+$n,$vr2+$n2)<2) {
        
        $subs=1;
    }elseif (min($vr1+$n,$vr2+$n2)>1 && min($vr1+$n,$vr2+$n2)<4) {
        $subs=2;
    }elseif (min($vr1+$n,$vr2+$n2)>3 && min($vr1+$n,$vr2+$n2)<8) {
        $subs=4;
    }elseif (min($vr1+$n,$vr2+$n2)>7 && min($vr1+$n,$vr2+$n2)<16) {
        $subs=8;
    }elseif (min($vr1+$n,$vr2+$n2)>15 && min($vr1+$n,$vr2+$n2)<32) {
        $subs=16;
    }elseif (min($vr1+$n,$vr2+$n2)>31 && min($vr1+$n,$vr2+$n2)<64) {
        $subs=32;
    }else{
        $subs=64;
    }
}else{
    $subs=0;
}

if ($subs==1) {
$nVV++;
if ($nVV==1) {
    # code...
 $subs=1;
}else{
    $subs=0;
}
}

$fb1=$balance1-$subs+$vr1;
$fb2=$balance2-$subs+$vr2;



$subsF+=$subs;
// echo $subsF;
// echo ($subs*3150);



$arAll[]=array('number' => $numSr,'start' => $startDate->format('Y/m/d'),'end'=>date('Y/m/d', strtotime($startDate->format('Y-m-d'). ' + 6 days')),'left' => $n,'right' => $n2,'total' => $n+$n2,'balance' => $subs );



    }
    
    $startDate->modify('+1 day');
}



if ($ArType=="N") {
return $ArN;
}elseif ($ArType=="L") {
return $ArL;
}elseif ($ArType=="R") {
return $ArR;
}elseif ($ArType=="T") {
return $ArT;
}elseif ($ArType=="A") {
return $arAll;
}else{

}

}
