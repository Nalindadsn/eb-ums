<?php include 'main.php';


include('admin/db.php');
include('admin/function.php');



$stmtAr = $pdo->prepare("SELECT * FROM accounts WHERE status=1");
$stmtAr->execute();
$accounts = $stmtAr->fetchAll(PDO::FETCH_ASSOC);
$stmtAr = $pdo->prepare("select username as id, email as email, user_id as parent_id,created_at from accounts WHERE status=1");
$stmtAr->execute();
// fetching rows into array
$tree_data = $stmtAr->fetchAll();



function fetch_recursive2($tree_data1, $currentid, $parentfound = false, $cats = array())
{
    foreach($tree_data1 as $row)
    {
        if((!$parentfound && $row['id'] == $currentid) || $row['parent_id'] == $currentid)
        {
            $rowdata = array();
            foreach($row as $k => $v)
                $rowdata[$k] = $v;
            $cats[] = $rowdata;
            if($row['parent_id'] == $currentid)
                $cats = array_merge($cats, fetch_recursive2($tree_data1, $row['id'], true));
        }
    }
    return $cats;
}





function userBal($tree_data,$left,$right){

global $pdo;
$subsF=0;
$pV=100;
$total=0;
$tp1=0;
$tp2=0;
$total2=0;
$subs=0;
$vr1=$vr2=$fb1=$fb2=0;
// $startDate = new DateTime('2021-01-24');
// $endDate = new DateTime('2021-02-22');


$stmta = $pdo->prepare("SELECT * FROM accounts WHERE status='1' AND role='Admin' ORDER BY id ASC LIMIT 1");
$stmta->execute();
// fetching rows into array
$dataaa = $stmta->fetchAll();

foreach ($dataaa as $keyData) {
$startDate = new DateTime(date('Y-m-d', strtotime($keyData['created_at'].'last sunday')));
$endDate = new DateTime(date('Y-m-d', strtotime(date("Y-m-d"))));
}




$sundays = array();
echo "<table class='table' border=1>";
?>


<tr>
  <th>Week Number</th>
  <th style="width: 40%;">Duration</th>
  <th >left</th>
  <th >right</th>
  <th >pay</th>
  <th >balance</th>
</tr>


<?php
$numSr=0;

$nVV=0;
$pre1=0;
$pre2=0;
while ($startDate <= $endDate) {
    if ($startDate->format('w') == 0) {


$n=0;
$n2=0;
$numV=0;
$numSr++;
$pre1=0;
$pre2=0;
foreach (fetch_recursive2($tree_data,$left) as $key11) {
 // echo $key11['created_at']."<br>";
//if ($key11['id']!=$_SESSION['name']) {
  //echo $key11['id'];

$tm=$key11['created_at'];

$time = $startDate->format('Y-m-d');

$date_one = $time; 
$date_one = strtotime($date_one);
$date_one = strtotime("+60 minutes", $date_one);
$date_one =  date('Y-m-d h:i A', $date_one);

$date_ten = strtotime($time); 
$date_ten = strtotime("-12 minutes", $date_ten); 
$date_ten = date('Y-m-d h:i A', $date_ten);

$paymentDate= date('Y-m-d', strtotime($tm) );

$contractDateBegin = date('Y-m-d h:i A', strtotime($date_ten)); 
$contractDateEnd = date('Y-m-d h:i A', strtotime($date_one));



$contractDateEnd=date('Y-m-d', strtotime($startDate->format('Y-m-d'). ' + 7 days'));



if($paymentDate > $contractDateBegin && $paymentDate < $contractDateEnd)  
{  
  $n++;
} 



//}

}

$one=0;
$one1=0;
$two=0;
$tpF=0;
$tpFF=0;

foreach (fetch_recursive2($tree_data,$right) as $key11) {
 // echo $key11['created_at']."<br>";
//if ($key11['id']!=$_SESSION['name']) {
  //echo $key11['id'];

$tm=$key11['created_at'];

$time = $startDate->format('Y-m-d');

$date_one = $time; 
$date_one = strtotime($date_one);
$date_one = strtotime("+60 minutes", $date_one);
$date_one =  date('Y-m-d h:i A', $date_one);

$date_ten = strtotime($time); 
$date_ten = strtotime("-12 minutes", $date_ten); 
$date_ten = date('Y-m-d h:i A', $date_ten);

$paymentDate= date('Y-m-d', strtotime($tm) );

$contractDateBegin = date('Y-m-d h:i A', strtotime($date_ten)); 
$contractDateEnd = date('Y-m-d h:i A', strtotime($date_one));



$contractDateEnd=date('Y-m-d', strtotime($startDate->format('Y-m-d'). ' + 7 days'));



if($paymentDate > $contractDateBegin && $paymentDate < $contractDateEnd)  
{  
  $n2++;
}
//}

}


// $arrD[] = array('name' => $n );
// $sundays[] = $startDate->format('Y-m-d');

//--if ($n>0 || $n2>0) {

        echo "<tr>";

  echo "<td class='text-center'>";
   echo $numSr; 
  echo "</td>";
?>     
<?php

        echo "<td>From:".$startDate->format('Y/m/d')."<br>";

        echo "To:".date('Y/m/d', strtotime($startDate->format('Y-m-d'). ' + 6 days'))."<br>";

/////////////////////////////////////////////
?>

<a style="font-size: 13px;" href="get_week_data.php?start=<?php echo $startDate->format('Y/m/d'); ?>&end=<?php echo date('Y/m/d', strtotime($startDate->format('Y-m-d'). ' + 6 days'))." "; ?>"> Week Users</a><br>
<a style="font-size: 13px;" href="usersw.php?start=<?php echo $startDate->format('Y/m/d'); ?>&end=<?php echo date('Y/m/d', strtotime($startDate->format('Y-m-d'). ' + 6 days'))." "; ?>">Balance Sheet</a>
   

<?php
 // $total+=($n*$pV);
 // $total2+=($n2*$pV);

$tpPre1=$pre1;
$tpPre2=$pre2;

$balance1=$tpPre1+$n;
$balance2=$tpPre2+$n2;



 $tp1+=$n;
 $tp2+=$n2;



$vr1=$fb1;
$vr2=$fb2;

if (min($vr1+$n,$vr2+$n2)>0) {

    if (min($vr1+$n,$vr2+$n2)>0 && min($vr1+$n,$vr2+$n2)<2) {
        
        $subs=1;
    }elseif (min($vr1+$n,$vr2+$n2)>1 && min($vr1+$n,$vr2+$n2)<4) {
        $subs=2;
    }elseif (min($vr1+$n,$vr2+$n2)>3 && min($vr1+$n,$vr2+$n2)<8) {
        $subs=4;
    }elseif (min($vr1+$n,$vr2+$n2)>7 && min($vr1+$n,$vr2+$n2)<16) {
        $subs=8;
    }elseif (min($vr1+$n,$vr2+$n2)>15 && min($vr1+$n,$vr2+$n2)<32) {
        $subs=16;
    }elseif (min($vr1+$n,$vr2+$n2)>31 && min($vr1+$n,$vr2+$n2)<64) {
        $subs=32;
    }else{
        $subs=64;
    }
}else{
    $subs=0;
}




if ($subs==1) {
$nVV++;
if ($nVV==1) {
    # code...
 $subs=1;
}else{
    $subs=0;
}
}

$fb1=$balance1-$subs+$vr1;
$fb2=$balance2-$subs+$vr2;

//$minVal=min($vr1+$n,$vr2+$n2);


// $tp1=$tp1-$subs;
// $tp2=$tp2-$subs;

//echo $subs;

echo "</td>";


echo "<td align='right'>";
//echo " : ".$one."<br>";

echo $subs*3150;

$subsF+=$subs;
echo "<hr>";
//echo min($vr1+$n,$vr2+$n2);
echo $balance1."--".$balance2;
echo "<hr>";
//echo min($vr1+$n,$vr2+$n2);
echo $vr1+$n."--".$vr2+$n2;

echo "</td>";

echo "<td align='right'>";
echo "Units : ".$n."<br>";
echo "pre : ".$vr1."<br>";


echo "Total : ".$balance1."<br>";

echo "Min : ".$subs."<br>";
echo "F Bal : ".$fb1."<br>";
//echo "v1 : ".$vr1."<br>";



echo "</td>";


echo "<td align='right'>";
echo "Units : ".$n2."<br>";
echo "pre : ".$vr2."<br>";
echo "Total : ".$balance2."<br>";

echo "Min : ".$subs."<br>";
echo "F Bal : ".$fb2."<br>";
//echo "v2 : ".$vr2."<br>";
echo "</td>";




echo "<td align='right'>";
echo " : ".min($tp1,$tp2)."<br>";
echo "</td>";


$one=0;

?>

<?php
echo "</tr>";
//--}
//////////////////////////////////////

    }
    
    $startDate->modify('+1 day');
}



echo "</table>";



}




userBal($tree_data,$_GET['left'],$_GET['right']);
 ?>